package actions;

import gui.Gui;

public class Main
{
    public void main()
    {
        Gui g = new Gui();
        
        g.create();
    }
}
